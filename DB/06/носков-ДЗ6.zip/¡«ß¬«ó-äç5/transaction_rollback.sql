use employees;
/*
	Найти сотрудника с самой низкой на данный момент зарплатой;
    Выяснить, в каком отделе он работает;
    Начислить всем в отделе, кроме него, по 100 долларов;
    Передумать.
*/
set autocommit = 0;

start transaction;

set @emp_with_min_salary = (
	select emp_no from salaries
    where to_date > current_date()
    order by salary
    limit 0,1
);


set @dept_emp_with_min_salary = (
	select dept_no from dept_emp
    where emp_no = @emp_with_min_salary
    and to_date > current_date()
    );

update salaries s
	join dept_emp de on de.emp_no = s.emp_no
	set s.salary = s.salary + 100
	where de.dept_no = @dept_emp_with_min_salary
    and s.to_date > current_date()
    and de.emp_no <> @emp_with_min_salary;
    
rollback;