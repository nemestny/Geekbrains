use employees;
/*
	Приём сотрудника на работу
*/
set autocommit = 0;

start transaction;

set @new_emp_no = 500011;

insert into employees
value (@new_emp_no,'1986-01-01','Tester','Testoyan','M',current_date());

insert into dept_emp
value (@new_emp_no,'d005',current_date(),'9999-01-01');

insert into titles
value (@new_emp_no,'Engineer',current_date(),'9999-01-01');

insert into salaries
value (@new_emp_no, 50000, date_add(current_date(), interval 1 day),date_add(current_date(), interval 1 year));

commit;